// pages/chart/chart.js
var wxCharts = require("../../utils/wxcharts.js");//相对路径
Page({
 
    /**
     * 页面的初始数据
     */
    data: {
        imageWidth:0
    },
 
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
 
    },
 
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {
 
    },
 
    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {
        new wxCharts({
            canvasId: 'columnCanvas',
            type: 'column',
            categories: ['00:00-04:00', '04:00-08:00', '08:00-12:00', '12:00-16:00', '16:00-20:00', '20:00-24:00'],
            series: [{
                name: '昨日用电量',
                data: [8.26, 10.58, 28.69, 21.54,32.86, 29.17]
            }],
            yAxis: {
                format: function (val) {
                    return val + 'wh';
                },
                /*max:400,
                min:0*/
            },
            width: 320,
            height: 200
        });
    },
 
    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {
 
    },
 
    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {
 
    },
 
    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {
 
    },
 
    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {
 
    },
 
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {
 
    },

    back_main:function(event){
        //转换界面
          wx:wx.navigateTo({
            url: '/pages/index/index',
            
          })
      
      
        },
})